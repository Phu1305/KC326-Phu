const header = document.getElementById('header').innerHTML = `
<div class="background">
    <header>
    <div class="header_container">
        <div class="header_logo">
        <a href="https://www.ctu.edu.vn/"><img
            src="https://yu.ctu.edu.vn/images/upload/article/2020/03/0305-logo-ctu.png"
            alt="Logo Đại học Cần Thơ"></a>
        </div>
        <div class="wide">
        <nav class="header_nav">
            <ul>
            <li><a href="index.html"><i class="fas fa-home"></i>trang chủ</a></li>
            <li><a href="gioithieu.html"><i class="fas fa-users"></i>giới thiệu thành viên</a></li>
            <li><a href="dieukhien.html"><i class="far fa-lightbulb-on"></i>điều kiển</a></li>
            <li><a href="ketqua.html"><i class="fas fa-analytics"></i>kết quả</a></li>
            <li>
                <a href=""><i class="far fa-info-circle"></i>
                Thông tin thêm
                </a>
                <ul class="sub">
                <li><a href="https://www.ctu.edu.vn/">CTU</a></li>
                <li><a href="https://elearning.ctu.edu.vn/">Elearning</a></li>
                <li><a href="https://htql.ctu.edu.vn/">HTQL</a></li>
                </ul>
            </li>
            </ul>
        </nav>
        </div>
    </div>
    </header>
</div>
	`