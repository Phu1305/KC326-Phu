import {getFieldIngoreNull} from '/modules/thingspeak.js'

/* tạo chart */
const ctx = document.getElementById('myChart').getContext('2d');
const chart = new Chart(ctx, {
	type: 'scatter',
	data: [],
	options: {
		maintainAspectRatio: false,
		responsive: true,
	},
})

getFieldIngoreNull('field2', 2	)

